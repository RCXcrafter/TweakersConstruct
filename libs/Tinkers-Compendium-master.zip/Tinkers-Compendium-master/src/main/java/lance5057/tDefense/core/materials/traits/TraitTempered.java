package lance5057.tDefense.core.materials.traits;

import net.minecraft.util.text.TextFormatting;

public class TraitTempered extends AbstractTDTrait {

	public TraitTempered() {
		super("tempered", TextFormatting.DARK_GRAY);
	}
}
