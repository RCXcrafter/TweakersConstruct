package lance5057.tDefense.core.network;

public class ArmorNetwork
{
}
