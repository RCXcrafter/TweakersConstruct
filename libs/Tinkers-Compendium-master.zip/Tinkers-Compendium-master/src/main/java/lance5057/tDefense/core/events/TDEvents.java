package lance5057.tDefense.core.events;

import net.minecraftforge.common.MinecraftForge;

public class TDEvents {
	public void preInit() {
		//MinecraftForge.EVENT_BUS.register(ArmorRenderEvent.class);
	}

	public void init() {

	}

	public void postInit() {

	}
}
